#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Patch Agent  v2.2  -  Web UI
-----------------------------------------------------------------
Launch:
    python3 patch_web.py
Then open:  http://localhost:5000

Config:     config.yaml          (SSH credentials)
Servers:    servers_template.xlsx  (cluster / server / service list)

v2.2 changes:
  - Group column: optional "Group" column in Excel scopes round-robin
    dependency checks to the same sub-tier (web-tier, app-tier, etc.)
    Servers without a group value are excluded from dependency blocking.

v2.1 changes:
  - Status column: add "Status Check Command" column to Excel to enable
    green/red live status checks per service
  - Dependency check: if status check shows service already stopped,
    skip the stop action (don't double-stop)
  - Row selection fix: Apply now REPLACES selection (not additive)
  - Round-robin delay: prominent countdown log between servers
"""

import json
import logging
import os
import queue
import threading
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import yaml
import openpyxl
from flask import Flask, Response, jsonify, render_template, request

# -- optional paramiko ----------------------------------------------------
try:
    import paramiko
    _PARAMIKO = True
except ImportError:
    _PARAMIKO = False

# ========================================================================
#  App bootstrap
# ========================================================================

BASE_DIR    = Path(__file__).parent
CONFIG_PATH = BASE_DIR / "config.yaml"
EXCEL_PATH  = BASE_DIR / "servers_template.xlsx"
STATE_PATH  = BASE_DIR / "patch_state.json"
LOG_PATH    = BASE_DIR / "patch_agent.log"

app = Flask(__name__, template_folder=str(BASE_DIR / "templates"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("patch_web")

# -- in-memory job registry -----------------------------------------------
_jobs: dict[str, dict] = {}          # job_id -> { status, events_q, results }
_jobs_lock = threading.Lock()


# ========================================================================
#  Config
# ========================================================================

def load_config() -> dict:
    if not CONFIG_PATH.exists():
        return {"ssh": {}, "patching": {}}
    with open(CONFIG_PATH) as f:
        raw = yaml.safe_load(f)
    if not isinstance(raw, dict):
        return {"ssh": {}, "patching": {}}
    if not isinstance(raw.get("ssh"), dict):
        raw["ssh"] = {}
    if not isinstance(raw.get("patching"), dict):
        raw["patching"] = {}
    return raw


# ========================================================================
#  Excel loading
# ========================================================================

COL_MAP = {
    "id":                             "id",
    "cluster":                        "cluster",
    "server name":                    "server_name",
    "server":                         "server_name",
    "hostname / ip":                  "host",
    "hostname/ip":                    "host",
    "hostname":                       "host",
    "ip":                             "host",
    "host":                           "host",
    "service name":                   "service",
    "service":                        "service",
    "stop command":                   "stop_cmd",
    "stop":                           "stop_cmd",
    "start command":                  "start_cmd",
    "start":                          "start_cmd",
    "mode":                           "mode",
    "mode\n(round_robin / batch)":    "mode",
    # --- optional: per-server round-robin delay (seconds) ---
    "delay":                          "rr_delay",
    "delay (s)":                      "rr_delay",
    "delay(s)":                       "rr_delay",
    "rr delay":                       "rr_delay",
    "round robin delay":              "rr_delay",
    # --- optional: live status check ---
    "status check command":           "status_cmd",
    "status check":                   "status_cmd",
    "status cmd":                     "status_cmd",
    "check command":                  "status_cmd",
    # --- optional: server sub-group for scoped dependency checks ---
    "group":                          "group",
    "server group":                   "group",
    "tier":                           "group",
    "service group":                  "group",
    "notes":                          "notes",
}

REQUIRED = {"id", "cluster", "host", "service", "stop_cmd", "start_cmd", "mode"}


def load_servers(excel_path: Path = EXCEL_PATH) -> list[dict]:
    if not excel_path.exists():
        raise FileNotFoundError(f"Excel not found: {excel_path}")

    wb = openpyxl.load_workbook(excel_path, data_only=True)
    ws_name = next((s for s in wb.sheetnames if s.lower() != "legend"), wb.sheetnames[0])
    ws = wb[ws_name]

    raw_rows = list(ws.iter_rows(values_only=True))
    if not raw_rows:
        raise ValueError("Excel sheet is empty")

    raw_hdrs = [str(h).strip() if h else "" for h in raw_rows[0]]
    headers  = [COL_MAP.get(h.lower(), h.lower()) for h in raw_hdrs]

    missing = REQUIRED - set(headers)
    if missing:
        raise ValueError(f"Excel missing columns: {missing}")

    servers = []
    for row in raw_rows[1:]:
        rec = dict(zip(headers, row))
        if not rec.get("host"):
            continue
        try:
            rec["id"] = int(rec.get("id") or 0)
        except (TypeError, ValueError):
            rec["id"] = 0
        mode = str(rec.get("mode") or "batch").strip().lower()
        if mode not in ("round_robin", "batch"):
            mode = "batch"
        rec["mode"]        = mode
        rec["cluster"]     = str(rec.get("cluster") or "Default").strip()
        rec["server_name"] = str(rec.get("server_name") or rec["host"]).strip()
        rec["service"]     = str(rec.get("service") or "service").strip()
        rec["stop_cmd"]    = str(rec.get("stop_cmd") or "").strip()
        rec["start_cmd"]   = str(rec.get("start_cmd") or "").strip()
        rec["status_cmd"]  = str(rec.get("status_cmd") or "").strip()
        rec["group"]       = str(rec.get("group") or "").strip()
        rec["notes"]       = str(rec.get("notes") or "").strip()
        # Per-server RR delay: None means "use config default"
        raw_delay = rec.get("rr_delay")
        try:
            rec["rr_delay"] = float(raw_delay) if raw_delay not in (None, "", "None") else None
        except (TypeError, ValueError):
            rec["rr_delay"] = None
        servers.append(rec)

    return servers


def parse_row_selection(selection: str, all_ids: list[int]) -> list[int]:
    """
    Parse a row selection string like "1,3,5-10,14" into a sorted list of IDs.
    Returns all IDs if selection is empty or "*".
    """
    selection = selection.strip()
    if not selection or selection == "*":
        return sorted(all_ids)

    id_set = set()
    for part in selection.split(","):
        part = part.strip()
        if "-" in part:
            lo, _, hi = part.partition("-")
            try:
                id_set.update(range(int(lo.strip()), int(hi.strip()) + 1))
            except ValueError:
                pass
        else:
            try:
                id_set.add(int(part))
            except ValueError:
                pass

    valid = set(all_ids)
    return sorted(id_set & valid)


# ========================================================================
#  SSH helpers
# ========================================================================

def _ssh_connect(host: str, cfg: dict):
    ssh_cfg = cfg.get("ssh") or {}
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    kw = dict(
        hostname      = host,
        port          = int(ssh_cfg.get("port", 22)),
        username      = ssh_cfg.get("username", "root"),
        timeout       = float(ssh_cfg.get("connect_timeout", 15)),
        banner_timeout= 30,
        auth_timeout  = 30,
    )
    key_path = (ssh_cfg.get("private_key_path") or "").strip()
    password  = (ssh_cfg.get("password") or "").strip()
    if key_path:
        kw["key_filename"] = os.path.expanduser(key_path)
    elif password:
        kw["password"] = password
    c.connect(**kw)
    return c


def _run(client, cmd: str, timeout: float) -> tuple[int, str, str]:
    _, out, err = client.exec_command(cmd, timeout=timeout)
    code = out.channel.recv_exit_status()
    return code, out.read().decode().strip(), err.read().decode().strip()


def _check_status(row: dict, cfg: dict) -> str:
    """
    Run the status_cmd for a row.
    Returns "running", "stopped", "error", or "unknown".
    """
    if not row.get("status_cmd"):
        return "unknown"
    if not _PARAMIKO:
        return "unknown"
    try:
        client = _ssh_connect(row["host"], cfg)
        code, _, _ = _run(client, row["status_cmd"], 10.0)
        client.close()
        return "running" if code == 0 else "stopped"
    except Exception:
        return "error"


# ========================================================================
#  Job execution
# ========================================================================

def _emit(q: queue.Queue, level: str, message: str, extra: dict | None = None):
    """Push a log event onto the SSE queue."""
    ev = {
        "ts":      datetime.now(timezone.utc).strftime("%H:%M:%S"),
        "level":   level,   # ok | info | warn | error
        "message": message,
    }
    if extra:
        ev.update(extra)
    q.put(ev)
    getattr(logger, "info" if level in ("ok", "info") else level, logger.info)(message)


def execute_service(row: dict, action: str, cfg: dict,
                    dry_run: bool, q: queue.Queue) -> dict:
    """
    Perform STOP or START for a single service row.
    If status_cmd is set and service is already stopped, skip the stop.
    Returns a result dict.
    """
    host    = row["host"]
    service = row["service"]
    row_id  = row["id"]
    cmd     = row["stop_cmd"] if action == "stop" else row["start_cmd"]
    timeout = float((cfg.get("ssh") or {}).get("command_timeout", 30))
    label   = f"[{row_id}] {host} / {service}"

    result = {"id": row_id, "host": host, "service": service,
              "action": action, "status": "ok", "message": ""}

    if dry_run:
        _emit(q, "info", f"{label}  [DRY-RUN] Would {action}: {cmd}",
              {"row_id": row_id, "host": host, "service": service})
        result["message"] = f"Dry-run - would run: {cmd}"
        return result

    if not _PARAMIKO:
        msg = "paramiko not installed"
        _emit(q, "error", f"{label}  X  {msg}", {"row_id": row_id})
        result.update(status="error", message=msg)
        return result

    # -- Dependency check: skip STOP if service is already stopped ----------
    if action == "stop" and row.get("status_cmd"):
        try:
            chk_client = _ssh_connect(host, cfg)
            chk_code, _, _ = _run(chk_client, row["status_cmd"], 10.0)
            chk_client.close()
            if chk_code != 0:
                _emit(q, "warn",
                      f"{label}  -- Already stopped, skipping",
                      {"row_id": row_id, "host": host, "service": service})
                result["message"] = "Already stopped - skipped"
                return result
        except Exception:
            pass  # if status check fails, proceed with stop anyway

    try:
        client = _ssh_connect(host, cfg)
        code, out, err = _run(client, cmd, timeout)
        client.close()

        if code == 0:
            _emit(q, "ok",
                  f"{label}  OK  {'STOPPED' if action == 'stop' else 'STARTED'}",
                  {"row_id": row_id, "host": host, "service": service})
            result["message"] = f"Service {action}ped successfully"
        else:
            err_msg = err or out or f"exit {code}"
            _emit(q, "error", f"{label}  X  Failed to {action}: {err_msg}",
                  {"row_id": row_id, "host": host, "service": service})
            result.update(status="error",
                          message=f"Command failed: {err_msg}")

    except Exception as exc:
        _emit(q, "error", f"{label}  X  {exc}",
              {"row_id": row_id, "host": host, "service": service})
        result.update(status="error", message=str(exc))

    return result


def _process_server_group(group_rows: list[dict], action: str, cfg: dict,
                           dry_run: bool, q: queue.Queue) -> list[dict]:
    """
    Execute all services for one physical server.
    Stop order  = ascending row-ID
    Start order = descending row-ID (automatic reverse for dependency ordering)
    """
    if action == "stop":
        ordered = sorted(group_rows, key=lambda r: r["id"])
    else:
        ordered = sorted(group_rows, key=lambda r: r["id"], reverse=True)

    results = []
    for row in ordered:
        results.append(execute_service(row, action, cfg, dry_run, q))
    return results


def run_job(job_id: str, rows: list[dict], action: str,
            cfg: dict, dry_run: bool):
    """
    Background thread: groups rows by server, runs round-robin then batch.
    """
    with _jobs_lock:
        job = _jobs[job_id]
    q       = job["events_q"]
    results = []

    total_servers = 0

    try:
        # -- 1. Group rows by (cluster + host) ----------------------------
        server_groups: dict[tuple, list] = defaultdict(list)
        for row in rows:
            key = (row["cluster"], row["host"])
            server_groups[key].append(row)

        rr_groups    = [(k, v) for k, v in server_groups.items()
                        if v[0]["mode"] == "round_robin"]
        batch_groups = [(k, v) for k, v in server_groups.items()
                        if v[0]["mode"] == "batch"]

        # Build a map of (cluster, host) -> group name for scoped dependency checks
        server_group_map: dict[tuple, str] = {
            k: v[0].get("group", "") for k, v in server_groups.items()
        }

        total_servers = len(server_groups)
        _emit(q, "info",
              f"Job {job_id[:8]}  action={action.upper()}  "
              f"servers={total_servers} ({len(rr_groups)} round-robin, "
              f"{len(batch_groups)} batch)  dry_run={dry_run}",
              {"progress": 0, "total": total_servers})

        done  = 0
        delay = float((cfg.get("patching") or {}).get("round_robin_delay", 5))

        # -- 2. Round-robin phase -----------------------------------------
        if rr_groups:
            _emit(q, "info",
                  f"-- PHASE 1: Round-Robin  ({len(rr_groups)} servers) --")

            # --- Dependency pre-flight (STOP only) ---
            # Check which RR servers are already stopped BEFORE we start.
            # If any are unexpectedly down, we skip stopping the remaining
            # servers to avoid a total outage.
            already_stopped: set[tuple] = set()
            if action == "stop" and not dry_run:
                _emit(q, "info", "  Pre-flight: checking round-robin server statuses ...")
                pf_lock = threading.Lock()

                def _pf_check(key, group_rows):
                    chk = next((r for r in group_rows if r.get("status_cmd")), None)
                    if chk:
                        st = _check_status(chk, cfg)
                        if st == "stopped":
                            with pf_lock:
                                already_stopped.add(key)
                            _emit(q, "warn",
                                  f"  [pre-flight] {key[0]}/{key[1]} is already STOPPED")

                pf_threads = [
                    threading.Thread(target=_pf_check, args=(k, v), daemon=True)
                    for k, v in rr_groups
                ]
                for t in pf_threads: t.start()
                for t in pf_threads: t.join(timeout=20)

                if already_stopped:
                    _emit(q, "warn",
                          f"  {len(already_stopped)} server(s) already stopped — "
                          f"dependency check active for remaining servers")

            we_stopped: set[tuple] = set()   # servers we successfully stopped this run

            for idx, ((cluster, host), group_rows) in enumerate(rr_groups):
                key   = (cluster, host)
                sname = group_rows[0]["server_name"]

                # Dependency check: skip if any OTHER RR server in the SAME group
                # is unexpectedly stopped (group="" servers are excluded from check)
                if action == "stop" and not dry_run:
                    my_group = server_group_map.get(key, "")
                    blocking = [
                        f"{k[1]}" for k in already_stopped
                        if k != key
                        and k not in we_stopped
                        and my_group != ""                            # only if this server has a group
                        and server_group_map.get(k, "") == my_group  # same group only
                    ]
                    if blocking:
                        _emit(q, "warn",
                              f"  SKIP [{idx+1}/{len(rr_groups)}] {cluster} / {sname}"
                              f" — other RR server(s) already stopped: {', '.join(blocking)}")
                        done += 1
                        pct = int(done / total_servers * 100)
                        _emit(q, "warn", f"  Progress: {done}/{total_servers}",
                              {"progress": pct, "total": total_servers})
                        continue

                _emit(q, "info",
                      f"  [{idx+1}/{len(rr_groups)}] {cluster} / {sname} ({host})")
                res = _process_server_group(group_rows, action, cfg, dry_run, q)
                results.extend(res)

                # Track servers we stopped so dependency check ignores them
                if action == "stop" and all(r["status"] == "ok" for r in res):
                    we_stopped.add(key)

                done += 1
                pct = int(done / total_servers * 100)
                _emit(q, "info", f"  Progress: {done}/{total_servers}",
                      {"progress": pct, "total": total_servers})

                # Delay between round-robin servers (not after the last one)
                if idx < len(rr_groups) - 1 and not dry_run:
                    # Per-server delay from Excel, else config default
                    server_delay = group_rows[0].get("rr_delay")
                    effective_delay = server_delay if server_delay is not None else delay
                    if effective_delay > 0:
                        _emit(q, "warn",
                              f"  ~~~ Waiting {int(effective_delay)}s before next server ~~~")
                        time.sleep(effective_delay)

        # -- 3. Batch phase -----------------------------------------------
        if batch_groups:
            _emit(q, "info",
                  f"-- PHASE 2: Batch  ({len(batch_groups)} servers, parallel) --")
            batch_results: list = [None] * len(batch_groups)
            threads = []
            lock    = threading.Lock()

            def _run_group(idx, cluster, host, group_rows):
                sname = group_rows[0]["server_name"]
                _emit(q, "info", f"  Starting {cluster} / {sname} ({host}) ...")
                res = _process_server_group(group_rows, action, cfg, dry_run, q)
                with lock:
                    batch_results[idx] = res
                    nonlocal done
                    done += 1
                    pct = int(done / total_servers * 100)
                    _emit(q, "info", f"  Progress: {done}/{total_servers}",
                          {"progress": pct, "total": total_servers})

            max_w = int((cfg.get("patching") or {}).get("batch_max_workers", 10))
            sem   = threading.Semaphore(max_w)

            def _worker(idx, cluster, host, group_rows):
                with sem:
                    _run_group(idx, cluster, host, group_rows)

            for i, ((cluster, host), group_rows) in enumerate(batch_groups):
                t = threading.Thread(target=_worker,
                                     args=(i, cluster, host, group_rows),
                                     daemon=True)
                threads.append(t)
                t.start()

            for t in threads:
                t.join()

            for res in batch_results:
                if res:
                    results.extend(res)

        # -- 4. Done ------------------------------------------------------
        errors = sum(1 for r in results if r["status"] != "ok")
        _emit(q, "ok" if errors == 0 else "warn",
              f"-- COMPLETE  "
              f"processed={len(results)}  ok={len(results)-errors}  errors={errors} --",
              {"progress": 100, "total": total_servers, "done": True})

        _save_state(results, action)

        with _jobs_lock:
            _jobs[job_id]["status"]  = "done"
            _jobs[job_id]["results"] = results

    except Exception as exc:
        _emit(q, "error", f"Job crashed: {exc}", {"done": True})
        with _jobs_lock:
            _jobs[job_id]["status"] = "error"

    finally:
        q.put(None)   # sentinel -> SSE generator closes


# ========================================================================
#  State persistence
# ========================================================================

def _save_state(results: list[dict], action: str):
    state: dict = {}
    if STATE_PATH.exists():
        try:
            state = json.loads(STATE_PATH.read_text())
        except Exception:
            state = {}

    ts = datetime.now(timezone.utc).isoformat()
    session = {
        "action":     action,
        "started_at": ts,
        "results":    results,
        "summary": {
            "total":  len(results),
            "ok":     sum(1 for r in results if r["status"] == "ok"),
            "errors": sum(1 for r in results if r["status"] != "ok"),
        },
    }
    state.setdefault("sessions", []).append(session)
    STATE_PATH.write_text(json.dumps(state, indent=2))


def _load_state() -> dict:
    if not STATE_PATH.exists():
        return {"sessions": []}
    try:
        return json.loads(STATE_PATH.read_text())
    except Exception:
        return {"sessions": []}


# ========================================================================
#  Flask routes
# ========================================================================

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/servers")
def api_servers():
    """Return all server rows plus cluster list."""
    try:
        rows     = load_servers()
        clusters = sorted({r["cluster"] for r in rows})
        return jsonify({"rows": rows, "clusters": clusters})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/status", methods=["POST"])
def api_status():
    """
    Check live service status for a list of row IDs.
    Body: { row_ids: [1, 2, 3] }   (empty list = check all rows)
    Returns: { statuses: { "1": "running"|"stopped"|"error"|"unknown", ... } }

    Requires "Status Check Command" column in Excel.
    Command should exit 0 if running, non-zero if stopped.
    Example: systemctl is-active nginx
    """
    body    = request.get_json(force=True) or {}
    row_ids = set(int(x) for x in body.get("row_ids", []))

    try:
        all_rows = load_servers()
        rows     = [r for r in all_rows if not row_ids or r["id"] in row_ids]
        cfg      = load_config()

        statuses    = {}
        status_lock = threading.Lock()

        def check_row(row):
            rid    = row["id"]
            status = _check_status(row, cfg)
            with status_lock:
                statuses[str(rid)] = status

        max_w = int((cfg.get("patching") or {}).get("batch_max_workers", 10))
        sem   = threading.Semaphore(max_w)
        threads = []

        def worker(row):
            with sem:
                check_row(row)

        for r in rows:
            t = threading.Thread(target=worker, args=(r,), daemon=True)
            threads.append(t)
            t.start()

        for t in threads:
            t.join(timeout=25)

        return jsonify({"statuses": statuses})

    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@app.route("/api/job/start", methods=["POST"])
def api_job_start():
    """
    Body: { selection: "1,3,5-10", action: "stop"|"start", dry_run: bool }
    Returns: { job_id }
    """
    body    = request.get_json(force=True) or {}
    action  = body.get("action", "stop").lower()
    dry_run = bool(body.get("dry_run", False))
    sel_str = str(body.get("selection", "*"))

    if action not in ("stop", "start"):
        return jsonify({"error": "action must be 'stop' or 'start'"}), 400

    try:
        all_rows  = load_servers()
        all_ids   = [r["id"] for r in all_rows]
        sel_ids   = parse_row_selection(sel_str, all_ids)
        sel_rows  = [r for r in all_rows if r["id"] in set(sel_ids)]
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

    if not sel_rows:
        return jsonify({"error": "No rows matched the selection"}), 400

    cfg    = load_config()
    job_id = str(uuid.uuid4())

    with _jobs_lock:
        _jobs[job_id] = {
            "status":    "running",
            "action":    action,
            "dry_run":   dry_run,
            "selection": sel_str,
            "events_q":  queue.Queue(),
            "results":   [],
        }

    t = threading.Thread(
        target=run_job,
        args=(job_id, sel_rows, action, cfg, dry_run),
        daemon=True,
    )
    t.start()

    return jsonify({"job_id": job_id, "server_count": len(sel_rows)})


@app.route("/api/job/stream/<job_id>")
def api_job_stream(job_id: str):
    """SSE stream for real-time job events."""
    with _jobs_lock:
        job = _jobs.get(job_id)
    if not job:
        return jsonify({"error": "job not found"}), 404

    def _generate():
        q = job["events_q"]
        while True:
            try:
                ev = q.get(timeout=30)
            except queue.Empty:
                yield "event: heartbeat\ndata: {}\n\n"
                continue
            if ev is None:
                yield "event: done\ndata: {}\n\n"
                break
            yield f"data: {json.dumps(ev)}\n\n"

    return Response(_generate(),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})


@app.route("/api/job/<job_id>")
def api_job_status(job_id: str):
    with _jobs_lock:
        job = _jobs.get(job_id)
    if not job:
        return jsonify({"error": "not found"}), 404
    return jsonify({
        "status":  job["status"],
        "action":  job["action"],
        "results": job["results"],
    })


@app.route("/api/history")
def api_history():
    state    = _load_state()
    sessions = state.get("sessions", [])[-20:]
    sessions.reverse()
    return jsonify({"sessions": sessions})


@app.route("/api/resolve", methods=["POST"])
def api_resolve():
    """Resolve a selection string to matching row IDs (used by UI preview)."""
    body = request.get_json(force=True) or {}
    sel  = str(body.get("selection", ""))
    try:
        rows    = load_servers()
        all_ids = [r["id"] for r in rows]
        sel_ids = parse_row_selection(sel, all_ids)
        return jsonify({"ids": sel_ids, "count": len(sel_ids)})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ========================================================================
#  Entry point
# ========================================================================

if __name__ == "__main__":
    print("\n  Patch Agent  v2.1")
    print(f"  Config:  {CONFIG_PATH}")
    print(f"  Excel:   {EXCEL_PATH}")
    print(f"  Open:    http://localhost:5000\n")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
